package com.customerapi.customerservice.response;


public class ProductResponse {
	
	private long productid;
	private String productname;
	
	public long getProductid() {
		return productid;
	}
	public void setProductid(long productid) {
		this.productid = productid;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	

}
