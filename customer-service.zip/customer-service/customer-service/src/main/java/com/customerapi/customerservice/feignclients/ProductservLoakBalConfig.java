package com.customerapi.customerservice.feignclients;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.loadbalancer.annotation.LoadBalancerClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.reactive.function.client.WebClient;

@LoadBalancerClient(value="product-service")
public class ProductservLoakBalConfig {
	
	@LoadBalanced
		@Bean
		public WebClient.Builder webclientBuilder(){
			return WebClient.builder();
		

}
}
