package com.customerapi.customerservice.response;

import com.customerapi.customerservice.entity.Customer;

public class CustomerResponse {
	
	private long id;
	private String firstName;
	private String lastName;
	
	private ProductResponse productresponse;
	private OrderResponse orderresponse;
	
	public CustomerResponse(Customer customer) {
		this.id = customer.getId();
		this.firstName = customer.getFirstName();
		this.lastName = customer.getLastName();
		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public ProductResponse getProductresposne() {
		return productresponse;
	}

	public void setProductresposne(ProductResponse productresponse) {
		this.productresponse = productresponse;
	}

	public OrderResponse getOroductresposne() {
		return orderresponse;
	}

	public void setOrderresposne(OrderResponse orderresponse) {
		this.orderresponse = orderresponse;
	}
	

}
