package com.customerapi.customerservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.customerapi.customerservice.entity.Customer;
import com.customerapi.customerservice.repository.CustomerRepository;
import com.customerapi.customerservice.request.CreateCustomerRequest;
import com.customerapi.customerservice.response.CustomerResponse;
import com.customerapi.customerservice.response.OrderResponse;
import com.customerapi.customerservice.response.ProductResponse;


import reactor.core.publisher.Mono;


@Service
public class CustomerService {
	
	@Autowired
	CustomerRepository customeRepo;
	
	@Autowired
	WebClient webClient;
	@Autowired
	WebClient webClient1;
	
	public CustomerResponse createCustomer(CreateCustomerRequest createCustomerRequest) {

		Customer customer = new Customer();
		customer.setFirstName(createCustomerRequest.getFirstName());
		customer.setLastName(createCustomerRequest.getLastName());
		
		
		customer.setProductid(createCustomerRequest.getProductid());
		
		customer = customeRepo.save(customer);
		
		CustomerResponse customerResponse = new CustomerResponse(customer);
		
		customerResponse.setProductresposne(getProductById(customer.getProductid()));
		customerResponse.setOrderresposne(getOrderById(customer.getOrderid()));

		return customerResponse;
	}
	
	public CustomerResponse getById (long id) {
		Customer customer = customeRepo.findById(id).get();
		CustomerResponse customerResponse = new CustomerResponse(customer);
		
		customerResponse.setProductresposne(getProductById(customer.getProductid()));
		customerResponse.setOrderresposne(getOrderById(customer.getOrderid()));
		return customerResponse;
	}
	
	public ProductResponse getProductById (long productid) {
		Mono<ProductResponse> productResponse = 
				webClient.get().uri("/getById/" + productid)
		.retrieve().bodyToMono(ProductResponse.class);
		
		return productResponse.block();
	}
	
	public OrderResponse getOrderById (long orderid) {
		Mono<OrderResponse> orderResponse = 
				webClient1.get().uri("/getById/" + orderid)
		.retrieve().bodyToMono(OrderResponse.class);
		
		return orderResponse.block();
	}
	
	

}
