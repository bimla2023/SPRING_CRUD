package com.customerapi.customerservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.customerapi.customerservice.request.CreateCustomerRequest;
import com.customerapi.customerservice.response.CustomerResponse;
import com.customerapi.customerservice.service.CustomerService;


@RestController
@RequestMapping("/api/customer")
public class CustomerController {
	@Autowired
	CustomerService customerService;
	
	@PostMapping("/create")
	public CustomerResponse createCustomer (@RequestBody CreateCustomerRequest createCustomerRequest) {
		return customerService.createCustomer(createCustomerRequest);
	}
	
	@GetMapping("/getById/{id}")
	public CustomerResponse getById (@PathVariable long id) {
		return customerService.getById(id);
	}

}
