package com.customerapi.customerservice;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.reactive.function.client.WebClient;


@SpringBootApplication
@ComponentScan({"com.customerapi.customerservice.controller", "com.customerapi.customerservice.service"})
@EntityScan("com.customerapi.customerservice.entity")
@EnableJpaRepositories("com.customerapi.customerservice.repository")
@EnableEurekaClient
public class CustomerServiceApplication {

	@Value("${product.service.url}")
	private String productServiceUrl;
	
	@Value("${order.service.url}")
	private String orderServiceUrl;
	
	public static void main(String[] args) {
		SpringApplication.run(CustomerServiceApplication.class, args);
	}
	
	@Bean
	public WebClient webClient () {
		WebClient webClient =WebClient.builder()
				.baseUrl(productServiceUrl).build();
		
		return webClient;
	}
	
	@Bean
	public WebClient webClient1 () {
		WebClient webClient =WebClient.builder()
				.baseUrl(orderServiceUrl).build();
		
		return webClient;
	}


}
