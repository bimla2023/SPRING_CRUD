package com.customerapi.customerservice.response;


public class OrderResponse {
	
	private long orderid;

	private String orderType;

	public Long getOrderId() {
		return orderid;
	}

	public void setOrderId(long orderid) {
		this.orderid = orderid;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	

}
