package com.Springboot.Country.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Springboot.Country.exception.ResourceNotFoundException;
import com.Springboot.Country.model.Country;
import com.Springboot.Country.repository.CountryRepository;

import jakarta.transaction.Transactional;

@Service 
@Transactional
public class CountryServiceImpl implements CountryService {

	@Autowired
	CountryRepository countryRepo;
	@Override
	
	//create
	public Country createCountry(Country country) {
		
		return countryRepo.save(country);
	}

	@Override
	//update
	public Country updateCountry(Country country) {
		Optional<Country> countrydb = this.countryRepo.findById(country.getCountryid());
		if(countrydb.isPresent()) {
			Country countryUpdate = countrydb.get();
			countryUpdate.setCountryid(country.getCountryid());
			countryUpdate.setCountryName(country.getCountryName());
			countryUpdate.setCountryPopulation(country.getCountryPopulation());
			countryRepo.save(countryUpdate);
			return countryUpdate;
		}
		else {
			throw new ResourceNotFoundException("Record not found with country id : " +country.getCountryid());
		}
		
	}

	@Override
	//list all
	public List<Country> getAllCountry() {
	
		return this.countryRepo.findAll();
	}

	@Override
	//get by id
	public Country getCountryById(long countryid) {
		Optional<Country> countrydb = this.countryRepo.findById(countryid);
		if(countrydb.isPresent()) {
			return countrydb.get();
		}else {
			throw new ResourceNotFoundException("Record not found with country id : " +countryid);
		}
	
	}

	@Override
	//delete
	public void deleteCountry(long countryid) {
		Optional<Country> countrydb = this.countryRepo.findById(countryid);
		if(countrydb.isPresent()) {
			this.countryRepo.delete(countrydb.get());
		}else {
			throw new ResourceNotFoundException("Record not found with country id : " +countryid);
		}
		
	}

}
