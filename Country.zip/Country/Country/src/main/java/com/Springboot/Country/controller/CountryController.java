package com.Springboot.Country.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.Springboot.Country.model.Country;
import com.Springboot.Country.service.CountryService;


@RestController
@RequestMapping("/api/country/")
public class CountryController {

	@Autowired
	private CountryService countryService;

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public List<Country> getProducts() {
		return countryService.getAllCountry();

	}

	// create
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public Country create(@RequestBody Country country) {

		return countryService.createCountry(country);

	}

	@RequestMapping(value = "/findbyId/{countryid}", method = RequestMethod.GET)
	public Country findbyId(@PathVariable("countryid") long countryid) {
		return countryService.getCountryById(countryid);
	}

	// update
	@RequestMapping(value = "/update/{countryid}", method = RequestMethod.PUT)
	public Country updateProduct(@PathVariable long countryid, @RequestBody Country country) {
		country.setCountryid(countryid);
		return countryService.updateCountry(country);
	}
	
	@RequestMapping(value="/delete/{countryid}", method=RequestMethod.DELETE)
	public void delete(@PathVariable("countryid") int countryid) {
		countryService.deleteCountry(countryid);
		System.out.println("Deleted");
	}

}
