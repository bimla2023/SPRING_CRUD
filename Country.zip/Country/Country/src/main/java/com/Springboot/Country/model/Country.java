package com.Springboot.Country.model;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="country")
public class Country {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long countryid;
	@Column(name="countryName")
	private String countryName;
	@Column(name="countryPopulation")
	private String countryPopulation;
	
	public Country() {
		
	}
	public Country(long countryid, String countryName, String countryPopulation) {
		super();
		this.countryid = countryid;
		this.countryName = countryName;
		this.countryPopulation = countryPopulation;
	}
	public long getCountryid() {
		return countryid;
	}
	public void setCountryid(long countryid) {
		this.countryid = countryid;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public String getCountryPopulation() {
		return countryPopulation;
	}
	public void setCountryPopulation(String countryPopulation) {
		this.countryPopulation = countryPopulation;
	}
	
	
	

}
