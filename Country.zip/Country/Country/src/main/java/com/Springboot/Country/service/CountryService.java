package com.Springboot.Country.service;

import java.util.List;

import com.Springboot.Country.model.Country;

public interface CountryService {
	
	
	Country createCountry(Country country);
	Country updateCountry(Country country);
	List<Country> getAllCountry();
	Country getCountryById(long countryid);
	void deleteCountry(long countryid);
}
