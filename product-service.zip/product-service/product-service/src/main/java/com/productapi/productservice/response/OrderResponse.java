package com.productapi.productservice.response;

public class OrderResponse {
	private long orderid;
	private String orderType;
	
	public long getOrderId() {
		return orderid;
	}
	public void setOrderId(long order_Id) {
		this.orderid = order_Id;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	
	

}
