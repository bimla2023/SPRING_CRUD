package com.productapi.productservice.request;


public class CreateProductRequest {
	
	private String productname;

	private long order_Id;
	
	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public long getOrderId() {
		return order_Id;
	}

	public void setOrderId(long order_Id) {
		this.order_Id = order_Id;
	}
	
	
	
	

}
