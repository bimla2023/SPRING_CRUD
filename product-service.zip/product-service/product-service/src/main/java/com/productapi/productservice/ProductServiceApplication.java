package com.productapi.productservice;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.reactive.function.client.WebClient;

@SpringBootApplication

@ComponentScan({"com.productapi.productservice.controller", "com.productapi.productservice.service"})
@EntityScan("com.productapi.productservice.entity")
@EnableJpaRepositories("com.productapi.productservice.repository")
@EnableEurekaClient
public class ProductServiceApplication {

	@Value("${order.service.url}")
	private String orderServiceUrl;
	public static void main(String[] args) {
		SpringApplication.run(ProductServiceApplication.class, args);
	}

	@Bean
	public WebClient webClient () {
		WebClient webClient =WebClient.builder()
				.baseUrl(orderServiceUrl).build();
		
		return webClient;
	}
}
