package com.productapi.productservice.feignclients;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.loadbalancer.annotation.LoadBalancerClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.reactive.function.client.WebClient;



@LoadBalancerClient(value="order-service")
public class OrderSerLoadBalConfig {
	

	@LoadBalanced
	@Bean
	public WebClient.Builder webclientBuilder(){
		return WebClient.builder();
	}

}
