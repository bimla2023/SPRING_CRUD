package com.productapi.productservice.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;


import com.productapi.productservice.entity.Product;
import com.productapi.productservice.repository.ProductRepository;
import com.productapi.productservice.request.CreateProductRequest;
import com.productapi.productservice.response.OrderResponse;
import com.productapi.productservice.response.ProductResponse;

import reactor.core.publisher.Mono;


@Service
public class ProductService {

	
	@Autowired
	ProductRepository productRepo;
	
	@Autowired
	WebClient webClient;
	Logger logger = LoggerFactory.getLogger(ProductService.class);
	public ProductResponse createProduct(CreateProductRequest createproductrequest) {
		
		Product product = new Product();
		product.setProductname(createproductrequest.getProductname());
	
		product.setOrderId(createproductrequest.getOrderId());
		
		product = productRepo.save(product);
		ProductResponse productResponse = new ProductResponse(product);
		
		productResponse.setOrderResponse(getOrderById(product.getOrderId()));
		
		
		return  productResponse;
		
	}
	
	public ProductResponse getById (long id) {
		
		Product product = productRepo.findById(id).get();
		ProductResponse productResponse = new ProductResponse(product);
		productResponse.setOrderResponse(getOrderById(product.getOrderId()));
		
		return  productResponse;
	}
	
	public OrderResponse getOrderById (long id) {
		logger.info("Inside getById " + id);
		Mono<OrderResponse> orderResponse = 
				webClient.get().uri("/getById/" + id)
		.retrieve().bodyToMono(OrderResponse.class);
		
		return orderResponse.block();
	}
}
