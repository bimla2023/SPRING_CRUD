package com.productapi.productservice.response;

import com.productapi.productservice.entity.Product;

public class ProductResponse {
	
	
	private long productid;


	private String productname;

	private OrderResponse orderResponse;


	public ProductResponse(Product product) {
		
		this.productid = product.getProductid();
		this.productname = product.getProductname();
	}


	public long getProductid() {
		return productid;
	}


	public void setProductid(long productid) {
		this.productid = productid;
	}


	public String getProductname() {
		return productname;
	}


	public void setProductname(String productname) {
		this.productname = productname;
	}


	public OrderResponse getOrderResponse() {
		return orderResponse;
	}


	public void setOrderResponse(OrderResponse orderResponse) {
		this.orderResponse = orderResponse;
	}
	
	

}
