package com.productapi.productservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.productapi.productservice.request.CreateProductRequest;
import com.productapi.productservice.response.ProductResponse;
import com.productapi.productservice.service.ProductService;

@RestController
@RequestMapping("/api/product")
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@PostMapping("/create")
	public ProductResponse createProduct (@RequestBody CreateProductRequest createProductRequest) {
		return productService.createProduct(createProductRequest);
	}
	
	@GetMapping("/getById/{id}")
	public ProductResponse getById(@PathVariable long id) {
		return productService.getById(id);
	}

}
