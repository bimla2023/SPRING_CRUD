package com.orderapi.orderservice.request;

public class CreateOrderRequest {
	
	private String orderType;

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	
	

}
