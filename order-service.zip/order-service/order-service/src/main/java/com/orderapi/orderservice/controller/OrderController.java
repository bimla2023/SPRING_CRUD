package com.orderapi.orderservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.orderapi.orderservice.request.CreateOrderRequest;
import com.orderapi.orderservice.response.OrderResponse;
import com.orderapi.orderservice.service.OrderService;

@RestController
@RequestMapping("/api/order")
public class OrderController {
	
	@Autowired
	OrderService orderService;
	@PostMapping("/create")
	public OrderResponse createOrder (@RequestBody CreateOrderRequest createOrderRequest) {
		return orderService.createOrder(createOrderRequest);
	}
	
	@GetMapping("/getById/{id}")
	public OrderResponse getById(@PathVariable long id) {
		return orderService.getById(id);
	}
	

}
