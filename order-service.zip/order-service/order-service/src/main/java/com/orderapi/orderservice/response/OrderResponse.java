package com.orderapi.orderservice.response;

import com.orderapi.orderservice.entity.Order;

public class OrderResponse {

	
	private long orderId;
	private String orderType;
	
	public OrderResponse(Order order) {
		this.orderId = order.getId();
		this.orderType = order.getOrderType();
		
	}
	
	public long getOrderid() {
		return orderId;
	}
	public void setOrderid(long orderid) {
		this.orderId = orderid;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	
	
}
