package com.orderapi.orderservice.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.orderapi.orderservice.entity.Order;
import com.orderapi.orderservice.repository.OrderRepository;
import com.orderapi.orderservice.request.CreateOrderRequest;
import com.orderapi.orderservice.response.OrderResponse;



@Service
public class OrderService {
	
	Logger logger = LoggerFactory.getLogger(OrderService.class);
	
	@Autowired
	OrderRepository orderRepo;
	
	public OrderResponse createOrder(CreateOrderRequest createOrdersRequest) {
		
		Order order = new Order();
		order.setOrderType(createOrdersRequest.getOrderType());
		
		
		orderRepo.save(order);
		
		return new OrderResponse(order);
		
	}
	
	public OrderResponse getById (long id) {
		
		logger.info("Inside getById " + id);
		
		Order order = orderRepo.findById(id).get();
		
		return new OrderResponse(order);
	}

}
